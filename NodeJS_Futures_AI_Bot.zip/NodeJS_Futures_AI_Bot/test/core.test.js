import test from 'node:test';
import assert from 'node:assert/strict';
import { ema, rsi, featuresFromKlines } from '../src/indicators.js';
import { LogisticModel } from '../src/model.js';

test('EMA returns expected average for flat series', () => assert.equal(ema(Array(30).fill(10), 9), 10));
test('RSI handles rising prices', () => assert.equal(rsi(Array.from({length:20}, (_,i)=>i+1)), 100));
test('feature engine produces finite features', () => {
  const rows = Array.from({length:100}, (_,i)=>{const c=100+i*0.1;return [i*60000,c+0.2,c+0.5,c-0.5,c,100+i]});
  const f=featuresFromKlines(rows); assert.ok(f); assert.equal(f.vector.length,10); assert.ok(f.vector.every(Number.isFinite));
});
test('logistic model learns simple synthetic trend', () => {
  const samples=[]; for(let i=0;i<200;i++){const x=(i-100)/100;samples.push({x:[x, x*0.2,0,0,0,0,0,0,0,0],y:x>0?1:0});}
  const m=new LogisticModel(10);m.train(samples,{epochs:300,learningRate:0.1});assert.ok(m.predict([2,0.4,0,0,0,0,0,0,0,0])>0.7);assert.ok(m.predict([-2,-0.4,0,0,0,0,0,0,0,0])<0.3);
});
