# Node.js Futures AI Bot — Demo / Testnet / guarded Live

Node.js 20+ experimental Binance USDⓈ-M Futures bot. DEMO is the default. It scans 1-minute candles, builds a small logistic-regression classifier, and uses EMA agreement as a signal filter. **This is not a validated profitable strategy. Use Testnet first.**

## Important limitations and risk

- The model's displayed holdout accuracy is not profitability. No independent, cost-aware out-of-sample backtest is included.
- TESTNET/LIVE modes can submit market entries and exchange-hosted STOP_MARKET / TAKE_PROFIT_MARKET protection orders. If protection placement fails, the code attempts an emergency reduce-only close. Always verify the actual Binance position/order state manually.
- Time exit is checked on scan cycles, so it may execute later than the nominal 60–180 seconds. Stop/target orders are intended to remain exchange-side.
- Live execution is experimental. This build does not guarantee fills, exact loss limits, or profitability. Network failures, API restrictions, exchange changes, partial fills, funding, slippage, and position-mode settings can cause unexpected outcomes. It is not appropriate to leave unattended with real funds.
- Dashboard has no login/authentication and must stay on `127.0.0.1` or behind a properly secured private tunnel. Do not expose it to the public internet.
- API keys must have withdrawals disabled and IP restrictions enabled. Use separate keys for Testnet and Live.

## Setup

```bash
cp .env.example .env
cp secrets.example.json secrets.json
# Edit secrets.json only on your server; never send credentials in chat.
node --version
npm test
npm start
```

Open `http://127.0.0.1:8000` locally. For remote use, prefer SSH tunnelling:

```bash
ssh -L 8000:127.0.0.1:8000 your-user@YOUR_SERVER_IP
```

## API keys

`secrets.json` supports four fields:

```json
{
  "BINANCE_API_KEY": "",
  "BINANCE_API_SECRET": "",
  "BINANCE_TESTNET_API_KEY": "",
  "BINANCE_TESTNET_API_SECRET": ""
}
```

Keep `secrets.json` private; it is excluded by `.gitignore`. Public market data doesn't need API keys. For TESTNET, enter the Futures Testnet credentials in the `BINANCE_TESTNET_*` fields. For Live, use a dedicated key with futures trading permission only, withdrawals disabled, and IP restrictions.

## Modes

- **DEMO**: simulated positions only. Default after startup.
- **TESTNET**: requires Testnet API credentials and a successful signed account check. This can send test orders automatically when a valid signal appears.
- **LIVE**: no `.env` unlock condition. It requires dashboard confirmation phrase `I UNDERSTAND LIVE TRADING` and successful validation of the LIVE API credentials. It uses real funds and can cause losses. Do not activate it until Testnet behaviour has been independently verified.

Mode changes are rejected while a Testnet/Live position tracked by this process remains open. On a restart, the in-memory list of open live positions is not reconstructed automatically; check Binance positions and open orders manually before restarting or changing modes. Do not run multiple copies of this bot on the same account.

## Conservative execution defaults

- At most 2 bot-tracked concurrent positions.
- Signal confidence must be at least `max(MIN_CONFIDENCE, 0.68)` for execution.
- Position quantity is sized from a small fraction of available account balance and ATR-based stop distance, capped at roughly 1x wallet notional; exchange quantity/price filters are applied.
- The code attempts isolated margin and 1x leverage before entry.
- STOP_MARKET and TAKE_PROFIT_MARKET use mark price and `closePosition=true`.
- Time exit attempts a reduce-only market close.

These controls are not a substitute for independent risk supervision. The current implementation does **not** provide a fully verified account-wide daily-loss circuit breaker, robust restart reconciliation, comprehensive partial-fill handling, or a proven exchange-wide kill switch. Treat Live as experimental and keep it disabled until these are implemented and tested.

## Configuration

Optional settings can be configured in `.env` (it is not required to unlock LIVE):

- `MAX_SYMBOLS=0`: scan all active USDT-M perpetuals; a positive number limits to top symbols.
- `SCAN_INTERVAL_MS`: scan interval (minimum 30 seconds).
- `MIN_CONFIDENCE`: model confidence gate.

`live-config.json` is informational/configuration for small risk sizing. The execution module caps risk fraction at 0.25% and leverage at 1x.

## Tests

```bash
npm test
node --check src/app.js
node --check src/futuresExecution.js
```

Tests validate core indicators/model only; they do not verify actual Binance orders. Complete Testnet order, stop/target, time-exit, network-error, and restart tests before considering any Live use.


## Account dashboard (updated)

When TESTNET or LIVE is selected and verified, the dashboard has a separate exchange-account panel showing wallet balance, equity/margin balance, available balance, unrealized PnL, initial/maintenance margin, open positions, open orders, recent fills, and recent income records. It refreshes account information at most every 15 seconds. DEMO continues to use the paper account panel.

Security: `secrets.json` and `.env` contain private configuration and must never be shared or committed. This ZIP intentionally uses placeholder credentials. Edit the placeholders locally with the correct environment's credentials. Keep LIVE disabled in the dashboard until TESTNET is fully verified. If real API credentials were previously shared or included in an uploaded archive, revoke/rotate them at Binance immediately.
