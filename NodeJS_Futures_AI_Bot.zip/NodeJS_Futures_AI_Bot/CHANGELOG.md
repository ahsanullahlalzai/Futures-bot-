# Changelog

## v1.5 — guarded execution adapter
- Added signed Binance Futures REST client for Testnet and Live.
- Added exchange symbol filters and conservative quantity rounding.
- Added isolated-margin / 1x leverage attempt, market entry, exchange-hosted stop-loss and take-profit orders, and emergency reduce-only close attempt if protection setup fails.
- Added Testnet account credential check, Live server-side opt-in (`ENABLE_LIVE_TRADING=true`), and typed dashboard confirmation.
- DEMO remains default; credentials are read only from ignored `secrets.json`.
- Added explicit documentation of unverified risks and missing account-wide daily-loss/restart reconciliation controls.
