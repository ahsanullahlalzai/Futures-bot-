import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
const ROOT = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const DATA_DIR = path.join(ROOT, 'data'); fs.mkdirSync(DATA_DIR, { recursive: true });
const STATE_FILE = path.join(DATA_DIR, 'paper-state.json');
const dayKey = () => new Date().toISOString().slice(0, 10);
export class PaperTrader {
  constructor(config) {
    this.cfg = config; this.state = this.load() || { balance: config.startBalance, startingBalance: config.startBalance, open: [], trades: [], marks: {}, day: dayKey(), dayStartBalance: config.startBalance, halted: false };
    this.rollDay();
  }
  load() { try { return JSON.parse(fs.readFileSync(STATE_FILE, 'utf8')); } catch { return null; } }
  save() { const tmp = STATE_FILE + '.tmp'; fs.writeFileSync(tmp, JSON.stringify(this.state, null, 2)); fs.renameSync(tmp, STATE_FILE); }
  rollDay() { if (this.state.day !== dayKey()) { this.state.day = dayKey(); this.state.dayStartBalance = this.state.balance; this.state.halted = false; this.save(); } }
  unrealizedPnl() { return this.state.open.reduce((sum, t) => { const p = Number(this.state.marks?.[t.symbol] || t.entry); return sum + (p - t.entry) * t.quantity * (t.side === 'LONG' ? 1 : -1); }, 0); }
  equity() { return this.state.balance + this.unrealizedPnl(); }
  dayLossFraction() { return Math.max(0, (this.state.dayStartBalance - this.equity()) / Math.max(1, this.state.dayStartBalance)); }
  openTrade(signal) {
    this.rollDay(); if (this.state.halted || this.dayLossFraction() >= this.cfg.maxDailyLoss) { this.state.halted = true; return false; }
    if (this.state.open.length >= this.cfg.maxOpenTrades || this.state.open.some(t => t.symbol === signal.symbol)) return false;
    if (!['LONG', 'SHORT'].includes(signal.side) || signal.confidence < this.cfg.minConfidence || !(signal.price > 0)) return false;
    const riskCash = this.state.balance * this.cfg.riskPerTrade;
    const stopDistance = Math.max(signal.atr * 1.5, signal.price * 0.0015);
    const quantity = riskCash / stopDistance;
    if (!Number.isFinite(quantity) || quantity <= 0) return false;
    const side = signal.side; const stop = side === 'LONG' ? signal.price - stopDistance : signal.price + stopDistance;
    const targetDistance = stopDistance * 1.5;
    const target = side === 'LONG' ? signal.price + targetDistance : signal.price - targetDistance;
    const holdSeconds = signal.holdSeconds;
    this.state.open.push({ id: `${Date.now()}-${signal.symbol}`, symbol: signal.symbol, side, entry: signal.price, stop, target, quantity, riskCash, confidence: signal.confidence, openedAt: Date.now(), expiresAt: Date.now() + holdSeconds * 1000, holdSeconds, feeRate: this.cfg.feeRate, slippageRate: this.cfg.slippageRate });
    this.save(); return true;
  }
  mark(symbol, price) {
    if (!(price > 0)) return;
    this.state.marks = this.state.marks || {}; this.state.marks[symbol] = price;
    const keep = [];
    for (const t of this.state.open) {
      if (t.symbol !== symbol) { keep.push(t); continue; }
      const stopHit = t.side === 'LONG' ? price <= t.stop : price >= t.stop;
      const targetHit = t.side === 'LONG' ? price >= t.target : price <= t.target;
      if (stopHit) this.close(t, t.stop, 'STOP_LOSS');
      else if (targetHit) this.close(t, t.target, 'TAKE_PROFIT');
      else if (Date.now() >= t.expiresAt) this.close(t, price, 'TIME_EXIT');
      else keep.push(t);
    }
    this.state.open = keep; this.rollDay();
    if (this.dayLossFraction() >= this.cfg.maxDailyLoss) this.state.halted = true;
    this.save();
  }
  close(t, exitPrice, reason) {
    const slip = exitPrice * t.slippageRate;
    const adjustedExit = t.side === 'LONG' ? exitPrice - slip : exitPrice + slip;
    const gross = (adjustedExit - t.entry) * t.quantity * (t.side === 'LONG' ? 1 : -1);
    const fees = (t.entry + adjustedExit) * t.quantity * t.feeRate;
    const net = gross - fees; this.state.balance += net;
    this.state.trades.unshift({ ...t, exit: adjustedExit, exitAt: Date.now(), reason, grossPnl: gross, fees, netPnl: net, win: net > 0 });
    this.state.trades = this.state.trades.slice(0, 2000);
  }
  snapshot() {
    const closed = this.state.trades; const wins = closed.filter(t => t.netPnl > 0); const losses = closed.filter(t => t.netPnl <= 0);
    const grossWins = wins.reduce((s, t) => s + t.netPnl, 0); const grossLosses = -losses.reduce((s, t) => s + t.netPnl, 0);
    const pnl = this.state.balance - this.state.startingBalance;
    return { mode: 'PAPER ONLY', balance: this.state.balance, equity: this.equity(), unrealizedPnl: this.unrealizedPnl(), startingBalance: this.state.startingBalance, pnl, pnlPct: pnl / this.state.startingBalance * 100, open: this.state.open, trades: closed.slice(0, 100), totalTrades: closed.length, winRate: closed.length ? wins.length / closed.length * 100 : 0, profitFactor: grossLosses ? grossWins / grossLosses : (grossWins ? null : 0), dayLossPct: this.dayLossFraction() * 100, halted: this.state.halted, config: { riskPerTrade: this.cfg.riskPerTrade, maxDailyLoss: this.cfg.maxDailyLoss, maxOpenTrades: this.cfg.maxOpenTrades } };
  }
  reset() { this.state = { balance: this.cfg.startBalance, startingBalance: this.cfg.startBalance, open: [], trades: [], marks: {}, day: dayKey(), dayStartBalance: this.cfg.startBalance, halted: false }; this.save(); }
}
