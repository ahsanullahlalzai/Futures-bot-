import fs from 'node:fs';

function loadEnv() {
  try {
    const text = fs.readFileSync(new URL('../.env', import.meta.url), 'utf8');
    for (const line of text.split(/\r?\n/)) {
      const m = line.match(/^\s*([A-Za-z_][A-Za-z0-9_]*)\s*=\s*(.*?)\s*$/);
      if (m && !m[1].startsWith('#') && process.env[m[1]] === undefined) process.env[m[1]] = m[2].replace(/^['"]|['"]$/g, '');
    }
  } catch {}
}
loadEnv();
const num = (k, d) => Number.isFinite(Number(process.env[k])) ? Number(process.env[k]) : d;
export const config = {
  host: process.env.HOST || '127.0.0.1', port: num('PORT', 8000),
  scanIntervalMs: Math.max(30000, num('SCAN_INTERVAL_MS', 60000)),
  maxSymbols: Math.max(0, Math.min(1000, Math.floor(num('MAX_SYMBOLS', 0)))),
  klineLimit: Math.min(500, Math.max(100, Math.floor(num('KLINE_LIMIT', 240)))),
  startBalance: Math.max(10, num('PAPER_START_BALANCE', 1000)),
  riskPerTrade: Math.min(0.01, Math.max(0.0005, num('PAPER_RISK_PER_TRADE', 0.0025))),
  maxOpenTrades: Math.max(1, Math.floor(num('PAPER_MAX_OPEN_TRADES', 3))),
  maxDailyLoss: Math.min(0.1, Math.max(0.005, num('PAPER_MAX_DAILY_LOSS', 0.02))),
  maxTradesPerSymbol: Math.max(1, Math.floor(num('PAPER_MAX_TRADES_PER_SYMBOL', 1))),
  feeRate: Math.max(0, num('PAPER_FEE_RATE', 0.0005)),
  slippageRate: Math.max(0, num('PAPER_SLIPPAGE_RATE', 0.0003)),
  minConfidence: Math.min(0.9, Math.max(0.51, num('MIN_CONFIDENCE', 0.62))),
};
