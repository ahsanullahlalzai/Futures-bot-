const BASE = 'https://fapi.binance.com';
async function get(path) {
  const controller = new AbortController(); const timer = setTimeout(() => controller.abort(), 12000);
  try {
    const r = await fetch(BASE + path, { signal: controller.signal, headers: { 'user-agent': 'NodeJS-Futures-AI-PaperBot/1.0' } });
    if (!r.ok) throw new Error(`Binance HTTP ${r.status} for ${path}`);
    return await r.json();
  } finally { clearTimeout(timer); }
}
export async function getTopSymbols(limit = 0) {
  const [info, tickers] = await Promise.all([get('/fapi/v1/exchangeInfo'), get('/fapi/v1/ticker/24hr')]);
  const tradable = new Set(info.symbols.filter(s => s.status === 'TRADING' && s.contractType === 'PERPETUAL' && s.quoteAsset === 'USDT').map(s => s.symbol));
  const ranked = tickers.filter(t => tradable.has(t.symbol) && Number(t.lastPrice) > 0)
    .sort((a, b) => Number(b.quoteVolume) - Number(a.quoteVolume));
  // limit <= 0 means every currently trading USDT-margined perpetual contract.
  return (limit > 0 ? ranked.slice(0, limit) : ranked).map(t => t.symbol);
}
export async function getKlines(symbol, limit = 240) {
  const rows = await get(`/fapi/v1/klines?symbol=${encodeURIComponent(symbol)}&interval=1m&limit=${limit}`);
  return rows.filter(r => Array.isArray(r) && r.length >= 6);
}
export async function getMarkPrice(symbol) {
  const r = await get(`/fapi/v1/premiumIndex?symbol=${encodeURIComponent(symbol)}`); return Number(r.markPrice);
}
