// Small, dependency-free logistic-regression model. This is an experimental classifier,
// not a guarantee of future price direction.
const sigmoid = z => 1 / (1 + Math.exp(-Math.max(-30, Math.min(30, z))));
export class LogisticModel {
  constructor(size = 10) { this.weights = Array(size + 1).fill(0); this.trained = false; this.samples = 0; this.validationAccuracy = null; }
  predict(vector) {
    if (!this.trained || vector.length + 1 !== this.weights.length) return 0.5;
    let z = this.weights[0]; for (let i = 0; i < vector.length; i++) z += vector[i] * this.weights[i + 1];
    return sigmoid(z);
  }
  train(samples, { epochs = 500, learningRate = 0.03, l2 = 0.002 } = {}) {
    if (samples.length < 80) throw new Error(`Not enough training samples: ${samples.length}; need at least 80`);
    const split = Math.floor(samples.length * 0.8), train = samples.slice(0, split), val = samples.slice(split);
    const dims = this.weights.length - 1;
    const mean = Array(dims).fill(0), std = Array(dims).fill(1);
    for (const s of train) for (let j = 0; j < dims; j++) mean[j] += s.x[j] / train.length;
    for (let j = 0; j < dims; j++) { let v = 0; for (const s of train) v += (s.x[j] - mean[j]) ** 2 / train.length; std[j] = Math.sqrt(v) || 1; }
    const norm = x => x.map((v, j) => Math.max(-8, Math.min(8, (v - mean[j]) / std[j])));
    this.weights.fill(0);
    for (let ep = 0; ep < epochs; ep++) {
      const grad = Array(dims + 1).fill(0);
      for (const s of train) {
        const x = norm(s.x); let z = this.weights[0]; for (let j = 0; j < dims; j++) z += this.weights[j + 1] * x[j];
        const err = sigmoid(z) - s.y; grad[0] += err;
        for (let j = 0; j < dims; j++) grad[j + 1] += err * x[j];
      }
      const lr = learningRate / Math.sqrt(1 + ep / 100);
      for (let j = 0; j < this.weights.length; j++) this.weights[j] -= lr * (grad[j] / train.length + (j ? l2 * this.weights[j] : 0));
    }
    // Fold standardization into the weights so prediction uses raw features.
    const raw = Array(dims + 1); raw[0] = this.weights[0];
    for (let j = 0; j < dims; j++) { raw[0] -= this.weights[j + 1] * mean[j] / std[j]; raw[j + 1] = this.weights[j + 1] / std[j]; }
    this.weights = raw; this.trained = true; this.samples = samples.length;
    let correct = 0; for (const s of val) if ((this.predict(s.x) >= 0.5 ? 1 : 0) === s.y) correct++;
    this.validationAccuracy = val.length ? correct / val.length : null;
    return { samples: samples.length, trainSamples: train.length, validationSamples: val.length, validationAccuracy: this.validationAccuracy };
  }
}
