import http from 'node:http';
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { config } from './config.js';
import { featuresFromKlines } from './indicators.js';
import { LogisticModel } from './model.js';
import { getTopSymbols, getKlines, getMarkPrice } from './exchange.js';
import { PaperTrader } from './paperTrader.js';
import { FuturesExecution } from './futuresExecution.js';
import { loadRuntime, saveRuntime, saveScan, getHistory, createBackup } from './storage.js';

const ROOT = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
// Load simple KEY=VALUE entries from the project .env because this app may be
// launched with plain `node src/app.js` on Android (without Node --env-file).
try {
  const envText = fs.readFileSync(path.join(ROOT, '.env'), 'utf8');
  for (const rawLine of envText.split(/\r?\n/)) {
    const line = rawLine.trim();
    if (!line || line.startsWith('#')) continue;
    const match = line.match(/^([A-Za-z_][A-Za-z0-9_]*)\s*=\s*(.*)$/);
    if (!match) continue;
    let value = match[2].trim();
    if ((value.startsWith('"') && value.endsWith('"')) || (value.startsWith("'") && value.endsWith("'"))) value = value.slice(1, -1);
    if (process.env[match[1]] === undefined) process.env[match[1]] = value;
  }
} catch { /* .env is optional; API credentials can be supplied in secrets.json. */ }
const trader = new PaperTrader(config); const model = new LogisticModel(10);
const savedRuntime = loadRuntime();
const market = { status: 'starting', lastScan: null, symbols: [], signals: [], training: null, error: null, logs: [], ...(savedRuntime || {}) };
let tradingMode = 'DEMO';
let execution = null;
const livePositions = new Map();
const liveConfig = (() => { try { return JSON.parse(fs.readFileSync(new URL('../live-config.json', import.meta.url), 'utf8')); } catch { return {}; } })();
let modeMessage = 'DEMO فعال دی؛ حقیقي امرونه نه لېږل کېږي.';
const liveStats = { equity: null, open: [], lastError: null };
market.status = 'starting';
const log = (msg) => { const line = `${new Date().toISOString()} ${msg}`; console.log(line); market.logs.unshift(line); market.logs = market.logs.slice(0, 80); try { saveRuntime(market); } catch (e) { console.error('Could not persist runtime state:', e.message); } };
const sleep = ms => new Promise(r => setTimeout(r, ms));
function makeSamples(rows, symbol) {
  const samples = [];
  // Use only closed candles; label direction 3 minutes later. This is a simple research label.
  const usable = rows.slice(0, -1);
  for (let i = 60; i < usable.length - 3; i += 2) {
    const feat = featuresFromKlines(usable.slice(0, i + 1)); if (!feat) continue;
    const future = Number(usable[i + 3][4]);
    samples.push({ x: feat.vector, y: future > feat.price ? 1 : 0, symbol });
  }
  return samples;
}
async function mapLimit(items, limit, fn) {
  const out = Array(items.length); let next = 0;
  await Promise.all(Array.from({ length: Math.min(limit, items.length) }, async () => { while (true) { const i = next++; if (i >= items.length) return; try { out[i] = await fn(items[i], i); } catch (e) { out[i] = { error: e.message, item: items[i] }; } } }));
  return out;
}
async function scanOnce() {
  market.status = 'scanning'; market.error = null;
  const symbols = await getTopSymbols(config.maxSymbols); market.symbols = symbols;
  const results = await mapLimit(symbols, 3, async symbol => ({ symbol, rows: await getKlines(symbol, config.klineLimit) }));
  const valid = results.filter(x => x && x.rows && x.rows.length >= 100);
  const samples = valid.flatMap(x => makeSamples(x.rows, x.symbol));
  if (samples.length >= 80) {
    // Deterministic chronological split inside the model. Samples are pooled across selected liquid symbols.
    market.training = model.train(samples); log(`Model trained on ${samples.length} samples; holdout accuracy ${(market.training.validationAccuracy * 100).toFixed(1)}%`);
  } else {
    log(`Not enough training data (${samples.length} samples); model remains ${model.trained ? 'available' : 'untrained'}`);
  }
  const signals = [];
  for (const item of valid) {
    const feat = featuresFromKlines(item.rows.slice(0, -1)); if (!feat) continue;
    const pUp = model.predict(feat.vector), confidence = Math.max(pUp, 1 - pUp);
    let side = 'WAIT';
    const reasons = [];
    if (!model.trained) reasons.push('model not trained');
    if (confidence < config.minConfidence) reasons.push(`confidence ${(confidence * 100).toFixed(1)}% below ${(config.minConfidence * 100).toFixed(1)}%`);
    const longTrend = feat.price > feat.ema21 && feat.ema9 > feat.ema21;
    const shortTrend = feat.price < feat.ema21 && feat.ema9 < feat.ema21;
    if (model.trained && confidence >= config.minConfidence) {
      if (pUp >= 0.5 && longTrend) side = 'LONG';
      else if (pUp < 0.5 && shortTrend) side = 'SHORT';
      else if (pUp >= 0.5) reasons.push('upward model bias but EMA trend is not bullish');
      else reasons.push('downward model bias but EMA trend is not bearish');
    }
    if (side !== 'WAIT') reasons.push('model probability and EMA trend agree');
    const holdSeconds = confidence >= 0.78 ? 180 : confidence >= 0.68 ? 120 : 60;
    const signal = { symbol: item.symbol, side, price: feat.price, pUp, confidence, holdSeconds, atr: feat.atr, rsi: feat.rsi, volumeRatio: feat.volumeRatio, macdHistogram: feat.macdHistogram, timestamp: feat.timestamp, reason: reasons.join('; ') || 'No valid entry conditions' };
    signals.push(signal);
  }
  market.signals = signals.sort((a, b) => b.confidence - a.confidence); market.lastScan = Date.now(); market.status = 'running';
  for (const s of market.signals) {
    trader.mark(s.symbol, s.price);
    if (s.side !== 'WAIT') {
      if (tradingMode === 'DEMO') { const opened = trader.openTrade(s); if (opened) log(`PAPER OPEN ${s.side} ${s.symbol} @ ${s.price} confidence ${(s.confidence * 100).toFixed(1)}% hold ${s.holdSeconds}s`); }
      else if (execution && !livePositions.has(s.symbol) && livePositions.size < 2 && s.confidence >= Math.max(config.minConfidence, 0.68)) {
        try { const pos = await execution.open(s, { riskFraction: liveConfig.riskFraction || 0.001, maxLeverage: liveConfig.maxLeverage || 1 }); livePositions.set(s.symbol, pos); liveStats.lastError = null; log(`${tradingMode} OPEN ${pos.side} ${pos.symbol} qty=${pos.quantity} entry=${pos.entryPrice} SL=${pos.stop} TP=${pos.target}`); }
        catch (e) { liveStats.lastError = e.message; log(`${tradingMode} order rejected ${s.symbol}: ${e.message}`); }
      }
    }
  }
  // Time exit is secondary to exchange-hosted protective stop/target orders.
  if (execution) for (const [symbol, pos] of [...livePositions]) {
    if (Date.now() - pos.openedAt >= Math.max(60, Number(pos.holdSeconds || 60)) * 1000) {
      try { await execution.closePosition(pos); livePositions.delete(symbol); log(`${tradingMode} TIME_EXIT close requested ${symbol}`); }
      catch (e) { liveStats.lastError = e.message; log(`${tradingMode} TIME_EXIT error ${symbol}: ${e.message}`); }
    }
  }
  liveStats.open = [...livePositions.values()];
  // Update any open position from mark-price endpoint (best-effort; rate limited by small symbol count).
  const openSymbols = [...new Set(trader.state.open.map(t => t.symbol))];
  for (const symbol of openSymbols) {
    try { trader.mark(symbol, await getMarkPrice(symbol)); } catch (e) { log(`Mark price warning ${symbol}: ${e.message}`); }
  }
  const directional = market.signals.filter(s => s.side !== 'WAIT').length;
  saveScan({ timestamp: market.lastScan, symbolCount: symbols.length, validCount: valid.length, directionalSignals: directional, model: { trained: model.trained, samples: model.samples, validationAccuracy: model.validationAccuracy }, signals: market.signals });
  saveRuntime(market);
  log(`Scan complete: ${valid.length}/${symbols.length} symbols; ${directional} directional signals`);
}
async function loop() {
  while (true) {
    try { await scanOnce(); }
    catch (e) { market.status = 'error'; market.error = e.message; log(`Scan error: ${e.message}`); }
    await sleep(config.scanIntervalMs);
  }
}
const mime = { '.html': 'text/html; charset=utf-8', '.css': 'text/css; charset=utf-8', '.js': 'text/javascript; charset=utf-8', '.json': 'application/json; charset=utf-8' };
function sendJson(res, obj, status = 200) { res.writeHead(status, { 'content-type': 'application/json; charset=utf-8', 'cache-control': 'no-store' }); res.end(JSON.stringify(obj)); }
const server = http.createServer((req, res) => {
  const url = new URL(req.url, `http://${req.headers.host || 'localhost'}`);
  if (url.pathname === '/api/status') return sendJson(res, { mode: tradingMode, modeMessage, market, live: { ...liveStats, open: [...livePositions.values()] }, paper: trader.snapshot(), model: { trained: model.trained, samples: model.samples, validationAccuracy: model.validationAccuracy }, config: { maxSymbols: config.maxSymbols, scanAllSymbols: config.maxSymbols === 0, minConfidence: config.minConfidence, scanIntervalMs: config.scanIntervalMs } });
  if (url.pathname === '/api/account' && req.method === 'GET') { if (!execution || !['TESTNET','LIVE'].includes(tradingMode)) return sendJson(res, { ok:false, mode:tradingMode, error:'د حساب ژوندۍ معلومات یوازې د TESTNET یا LIVE حالت کې شته.' }, 409); execution.accountDashboard().then(data => sendJson(res, { ok:true, ...data })).catch(e => sendJson(res, { ok:false, mode:tradingMode, error:e.message }, 502)); return; }
  if (url.pathname === '/api/mode' && req.method === 'POST') { let body=''; req.on('data', c => { body += c; if (body.length > 2048) req.destroy(); }); req.on('end', async () => { try { const data=JSON.parse(body || '{}'); const requested=String(data.mode || '').toUpperCase(); if (requested === 'DEMO') { if (livePositions.size) return sendJson(res,{ok:false,error:'د حقیقي/ټیسټنېټ خلاص پوزیشنونه شته؛ لومړی یې وتړه.'},409); execution=null; tradingMode='DEMO'; modeMessage='DEMO فعال دی؛ یوازې خیالي معاملې کېږي.'; log('Trading mode set to DEMO'); return sendJson(res, { ok:true, mode:tradingMode, message:modeMessage }); }
if (!['TESTNET','LIVE'].includes(requested)) return sendJson(res,{ok:false,error:'DEMO, TESTNET یا LIVE وټاکئ.'},400);
if (livePositions.size) return sendJson(res,{ok:false,error:'تر mode بدلولو مخکې خلاصې معاملې وتړه.'},409);
if (requested === 'LIVE') {
  if (data.confirmation !== 'I UNDERSTAND LIVE TRADING') return sendJson(res,{ok:false,error:'د LIVE لپاره د تایید عبارت په سمه توګه ولیکه: I UNDERSTAND LIVE TRADING'},403);
}
try { const candidate = new FuturesExecution(requested); await candidate.cancelAndVerifyCredentials(); execution=candidate; tradingMode=requested; modeMessage=requested==='TESTNET'?'TESTNET فعال دی؛ ازمایښتي حساب کارول کېږي.':'LIVE فعال دی؛ حقیقي مالي خطر شته. دا سیستم د ګټې تضمین نه کوي.'; log(`Trading mode set to ${requested}; account API check succeeded`); return sendJson(res,{ok:true,mode:tradingMode,message:modeMessage}); }
catch(e) { execution=null; tradingMode='DEMO'; modeMessage=`د ${requested} حساب تایید ناکام شو؛ DEMO ته راستون شو.`; log(`Mode activation failed: ${e.message}`); return sendJson(res,{ok:false,mode:tradingMode,error:`${modeMessage} ${e.message}`},400); }
} catch { return sendJson(res,{ok:false,error:'JSON ناسم دی.'},400); } }); return; }
  if (url.pathname === '/api/scan' && req.method === 'POST') { scanOnce().then(() => log('Manual scan completed')).catch(e => { market.error = e.message; log(`Manual scan error: ${e.message}`); }); return sendJson(res, { accepted: true }); }
  if (url.pathname === '/api/reset' && req.method === 'POST') { trader.reset(); log('Paper account reset by local dashboard; historical scan data preserved'); return sendJson(res, { ok: true }); }
  if (url.pathname === '/api/logs') return sendJson(res, { logs: market.logs });
  if (url.pathname === '/api/history') return sendJson(res, { history: getHistory(url.searchParams.get('limit')) });
  if (url.pathname === '/api/backup') {
    const backup = createBackup(market, trader, model, config);
    res.writeHead(200, { 'content-type': 'application/json; charset=utf-8', 'content-disposition': `attachment; filename=trading-bot-backup-${new Date().toISOString().slice(0,10)}.json`, 'cache-control': 'no-store' });
    return res.end(JSON.stringify(backup, null, 2));
  }
  const pathname = url.pathname === '/' ? '/index.html' : url.pathname;
  const file = path.resolve(ROOT, 'public', `.${pathname}`);
  if (!file.startsWith(path.resolve(ROOT, 'public') + path.sep)) { res.writeHead(403); return res.end('Forbidden'); }
  fs.readFile(file, (err, data) => { if (err) { res.writeHead(404); return res.end('Not found'); } res.writeHead(200, { 'content-type': mime[path.extname(file)] || 'application/octet-stream', 'x-content-type-options': 'nosniff' }); res.end(data); });
});
server.listen(config.port, config.host, () => { log(`Dashboard listening on http://${config.host}:${config.port} (DEMO default; TESTNET and LIVE require valid credentials and dashboard confirmation)`); loop(); });
process.on('SIGINT', () => { log('Stopping'); try { saveRuntime(market); } catch {} server.close(() => process.exit(0)); });
process.on('SIGTERM', () => { try { saveRuntime(market); } catch {} server.close(() => process.exit(0)); });
