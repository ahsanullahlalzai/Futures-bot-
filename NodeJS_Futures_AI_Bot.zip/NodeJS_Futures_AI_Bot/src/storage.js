import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const ROOT = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
export const DATA_DIR = path.join(ROOT, 'data');
const RUNTIME_FILE = path.join(DATA_DIR, 'runtime-state.json');
const HISTORY_FILE = path.join(DATA_DIR, 'scan-history.json');
const MAX_SCANS = 1000;
fs.mkdirSync(DATA_DIR, { recursive: true });

function atomicWrite(file, value) {
  const tmp = `${file}.tmp`;
  fs.writeFileSync(tmp, JSON.stringify(value, null, 2));
  fs.renameSync(tmp, file);
}
function readJson(file, fallback) {
  try { return JSON.parse(fs.readFileSync(file, 'utf8')); } catch { return fallback; }
}
export function loadRuntime() {
  return readJson(RUNTIME_FILE, null);
}
export function saveRuntime(market) {
  atomicWrite(RUNTIME_FILE, {
    savedAt: new Date().toISOString(),
    status: market.status,
    lastScan: market.lastScan,
    symbols: market.symbols,
    signals: market.signals,
    training: market.training,
    error: market.error,
    logs: market.logs
  });
}
export function saveScan(scan) {
  const history = readJson(HISTORY_FILE, []);
  history.push(scan);
  atomicWrite(HISTORY_FILE, history.slice(-MAX_SCANS));
}
export function getHistory(limit = 100) {
  const history = readJson(HISTORY_FILE, []);
  return history.slice(-Math.max(1, Math.min(1000, Number(limit) || 100))).reverse();
}
export function createBackup(market, paper, model, config) {
  return {
    app: 'NodeJS Futures AI Paper Bot',
    backupVersion: 1,
    exportedAt: new Date().toISOString(),
    note: 'Public market scan history and paper-trading data. Raw exchange candles are not archived.',
    config: { maxSymbols: config.maxSymbols, scanIntervalMs: config.scanIntervalMs, klineLimit: config.klineLimit, minConfidence: config.minConfidence },
    market,
    model: { trained: model.trained, samples: model.samples, validationAccuracy: model.validationAccuracy },
    paper: paper.state,
    scanHistory: readJson(HISTORY_FILE, [])
  };
}
