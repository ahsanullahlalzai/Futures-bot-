function emaSeries(values, period) {
  const out = Array(values.length).fill(null); if (values.length < period) return out;
  const k = 2 / (period + 1); let v = values.slice(0, period).reduce((a, b) => a + b, 0) / period; out[period - 1] = v;
  for (let i = period; i < values.length; i++) { v = values[i] * k + v * (1 - k); out[i] = v; }
  return out;
}
export function ema(values, period) { const s = emaSeries(values, period); return s.at(-1) ?? null; }
export function rsi(values, period = 14) {
  if (values.length <= period) return 50;
  let gains = 0, losses = 0;
  for (let i = values.length - period; i < values.length; i++) { const d = values[i] - values[i - 1]; if (d > 0) gains += d; else losses -= d; }
  if (losses === 0) return gains === 0 ? 50 : 100;
  return 100 - 100 / (1 + gains / losses);
}
export function featuresFromKlines(klines) {
  if (!Array.isArray(klines) || klines.length < 60) return null;
  const close = klines.map(k => Number(k[4])), high = klines.map(k => Number(k[2])), low = klines.map(k => Number(k[3])), vol = klines.map(k => Number(k[5]));
  if ([...close, ...high, ...low, ...vol].some(x => !Number.isFinite(x) || x <= 0)) return null;
  const last = close.at(-1), prev = close.at(-2), e9 = ema(close, 9), e21 = ema(close, 21), e50 = ema(close, 50);
  const e12s = emaSeries(close, 12), e26s = emaSeries(close, 26);
  const macd = close.map((_, i) => e12s[i] !== null && e26s[i] !== null ? e12s[i] - e26s[i] : null).filter(v => v !== null);
  const macdSignal = ema(macd, 9) ?? 0, macdLine = macd.at(-1) ?? 0;
  let tr = 0; for (let i = close.length - 14; i < close.length; i++) tr += Math.max(high[i] - low[i], Math.abs(high[i] - close[i - 1]), Math.abs(low[i] - close[i - 1]));
  const atrPct = (tr / 14) / last, avgVol = vol.slice(-21, -1).reduce((a, b) => a + b, 0) / 20;
  const volumeRatio = avgVol > 0 ? vol.at(-1) / avgVol : 1, r = rsi(close, 14);
  const f = [(r - 50) / 50, (last / e9 - 1) * 100, (last / e21 - 1) * 100, (last / e50 - 1) * 100, ((macdLine - macdSignal) / last) * 1000, Math.min(atrPct * 100, 10), Math.max(-5, Math.min(5, volumeRatio - 1)), (last / prev - 1) * 100, (last / close.at(-4) - 1) * 100, (last / close.at(-11) - 1) * 100];
  if (f.some(x => !Number.isFinite(x))) return null;
  return { vector: f, price: last, rsi: r, ema9: e9, ema21: e21, ema50: e50, atr: atrPct * last, atrPct, volumeRatio, macdHistogram: macdLine - macdSignal, timestamp: Number(klines.at(-1)[0]) };
}
