import fs from 'node:fs';
import crypto from 'node:crypto';

const SECRETS_PATH = new URL('../secrets.json', import.meta.url);
function secrets() {
  try { return JSON.parse(fs.readFileSync(SECRETS_PATH, 'utf8')); }
  catch { throw new Error('secrets.json نه لوستل کېږي؛ د secrets.example.json کاپي او تنظیم یې کړه.'); }
}
const sleep = ms => new Promise(r => setTimeout(r, ms));
export class FuturesExecution {
  constructor(mode = 'TESTNET') {
    this.mode = mode;
    this.base = mode === 'TESTNET' ? 'https://testnet.binancefuture.com' : 'https://fapi.binance.com';
    this.keyName = mode === 'TESTNET' ? 'BINANCE_TESTNET_API_KEY' : 'BINANCE_API_KEY';
    this.secretName = mode === 'TESTNET' ? 'BINANCE_TESTNET_API_SECRET' : 'BINANCE_API_SECRET';
    this.meta = null;
  }
  credentials() {
    const s = secrets(); const key = s[this.keyName] || ''; const secret = s[this.secretName] || '';
    if (!key || !secret || key.includes('YOUR_') || secret.includes('YOUR_')) throw new Error(`${this.keyName}/${this.secretName} په secrets.json کې تنظیم کړه.`);
    return { key, secret };
  }
  async request(method, path, params = {}, signed = false) {
    const p = { ...params };
    const headers = {};
    if (signed) {
      const { key, secret } = this.credentials(); p.timestamp = Date.now(); p.recvWindow = 5000;
      const query = new URLSearchParams(p).toString();
      p.signature = crypto.createHmac('sha256', secret).update(query).digest('hex');
      headers['X-MBX-APIKEY'] = key;
    }
    const query = new URLSearchParams(p).toString();
    const url = this.base + path + (query ? `?${query}` : '');
    const controller = new AbortController(); const timer = setTimeout(() => controller.abort(), 10000);
    try {
      const res = await fetch(url, { method, headers, signal: controller.signal });
      const data = await res.json().catch(() => ({}));
      if (!res.ok) throw new Error(`Binance ${res.status}: ${data.msg || JSON.stringify(data)}`);
      return data;
    } finally { clearTimeout(timer); }
  }
  async public(path, params = {}) { return this.request('GET', path, params, false); }
  async signed(method, path, params = {}) { return this.request(method, path, params, true); }
  async exchangeInfo() { if (!this.meta) this.meta = await this.public('/fapi/v1/exchangeInfo'); return this.meta; }
  async rules(symbol) {
    const info = await this.exchangeInfo(); const s = info.symbols.find(x => x.symbol === symbol && x.status === 'TRADING');
    if (!s) throw new Error(`${symbol}: active trading pair not found`);
    const filters = Object.fromEntries(s.filters.map(f => [f.filterType, f]));
    return { step: Number(filters.LOT_SIZE?.stepSize || 0.001), minQty: Number(filters.LOT_SIZE?.minQty || 0), tick: Number(filters.PRICE_FILTER?.tickSize || 0.0001), minNotional: Number(filters.MIN_NOTIONAL?.notional || filters.NOTIONAL?.minNotional || 5), filters };
  }
  floorStep(value, step) { const decimals = Math.max(0, (String(step).split('.')[1] || '').replace(/0+$/, '').length); return Number((Math.floor(value / step + 1e-10) * step).toFixed(decimals)); }
  priceStep(value, tick, roundUp = false) { const decimals = Math.max(0, (String(tick).split('.')[1] || '').replace(/0+$/, '').length); const units = roundUp ? Math.ceil(value / tick - 1e-10) : Math.floor(value / tick + 1e-10); return Number((units * tick).toFixed(decimals)); }
  async open(signal, risk = {}) {
    if (!['LONG','SHORT'].includes(signal.side) || !(signal.price > 0) || !(signal.atr > 0)) throw new Error('Invalid entry signal');
    const rules = await this.rules(signal.symbol);
    const account = await this.signed('GET', '/fapi/v2/account');
    const wallet = Number(account.availableBalance || account.totalWalletBalance || 0);
    const riskFraction = Math.min(0.0025, Math.max(0.0005, Number(risk.riskFraction || 0.001)));
    const stopDistance = Math.max(signal.atr * 1.5, signal.price * 0.002);
    const riskCash = wallet * riskFraction;
    let qty = this.floorStep(riskCash / stopDistance, rules.step);
    const maxNotional = wallet * Math.min(2, Math.max(1, Number(risk.maxLeverage || 1)));
    qty = this.floorStep(Math.min(qty, maxNotional / signal.price), rules.step);
    if (qty < rules.minQty || qty * signal.price < rules.minNotional) throw new Error(`${signal.symbol}: calculated quantity below exchange minimum; skipped`);
    const entrySide = signal.side === 'LONG' ? 'BUY' : 'SELL'; const exitSide = entrySide === 'BUY' ? 'SELL' : 'BUY';
    // Force isolated, 1x leverage to reduce accidental leverage exposure; fail closed if exchange rejects it.
    await this.signed('POST', '/fapi/v1/marginType', { symbol: signal.symbol, marginType: 'ISOLATED' }).catch(e => { if (!String(e.message).includes('No need to change margin type')) throw e; });
    await this.signed('POST', '/fapi/v1/leverage', { symbol: signal.symbol, leverage: 1 });
    const stopRaw = signal.side === 'LONG' ? signal.price - stopDistance : signal.price + stopDistance;
    const targetRaw = signal.side === 'LONG' ? signal.price + stopDistance * 1.5 : signal.price - stopDistance * 1.5;
    const stop = this.priceStep(stopRaw, rules.tick, signal.side === 'SHORT');
    const target = this.priceStep(targetRaw, rules.tick, signal.side === 'LONG');
    // Entry is placed only after explicit server-side LIVE unlock; protection orders are then placed immediately.
    const entry = await this.signed('POST', '/fapi/v1/order', { symbol: signal.symbol, side: entrySide, type: 'MARKET', quantity: qty, newOrderRespType: 'RESULT' });
    try {
      await this.signed('POST', '/fapi/v1/order', { symbol: signal.symbol, side: exitSide, type: 'STOP_MARKET', stopPrice: stop, closePosition: 'true', workingType: 'MARK_PRICE' });
      await this.signed('POST', '/fapi/v1/order', { symbol: signal.symbol, side: exitSide, type: 'TAKE_PROFIT_MARKET', stopPrice: target, closePosition: 'true', workingType: 'MARK_PRICE' });
    } catch (e) {
      // Emergency reduce-only market close if protection could not be established.
      try { await this.signed('POST', '/fapi/v1/order', { symbol: signal.symbol, side: exitSide, type: 'MARKET', quantity: qty, reduceOnly: 'true', newOrderRespType: 'RESULT' }); } catch (closeErr) { throw new Error(`CRITICAL: protective orders failed (${e.message}); emergency close also failed (${closeErr.message}). Check Binance positions immediately.`); }
      throw new Error(`Protective orders failed; emergency close attempted: ${e.message}`);
    }
    return { symbol: signal.symbol, side: signal.side, quantity: qty, entryPrice: Number(entry.avgPrice || signal.price), stop, target, orderId: entry.orderId, holdSeconds: signal.holdSeconds, openedAt: Date.now() };
  }
  async closePosition(position) {
    const positions = await this.signed('GET', '/fapi/v2/positionRisk', { symbol: position.symbol });
    const p = positions.find(x => x.symbol === position.symbol && Number(x.positionAmt) !== 0);
    if (!p) return { alreadyClosed: true };
    const amt = Math.abs(Number(p.positionAmt)); const side = Number(p.positionAmt) > 0 ? 'SELL' : 'BUY';
    const result = await this.signed('POST', '/fapi/v1/order', { symbol: position.symbol, side, type: 'MARKET', quantity: amt, reduceOnly: 'true', newOrderRespType: 'RESULT' });
    // Remove stale conditional orders after position close.
    try { await this.signed('DELETE', '/fapi/v1/allOpenOrders', { symbol: position.symbol }); } catch {}
    return result;
  }
  async accountDashboard() {
    // Read-only account view. Never returns API credentials.
    const [account, positions, openOrders, userTrades, income] = await Promise.all([
      this.signed('GET', '/fapi/v2/account'),
      this.signed('GET', '/fapi/v2/positionRisk'),
      this.signed('GET', '/fapi/v1/openOrders'),
      this.signed('GET', '/fapi/v1/userTrades', { limit: 100 }),
      this.signed('GET', '/fapi/v1/income', { limit: 100 })
    ]);
    const assets = (account.assets || []).filter(a => Number(a.walletBalance || 0) !== 0 || Number(a.unrealizedProfit || 0) !== 0 || Number(a.availableBalance || 0) !== 0);
    const openPositions = (positions || []).filter(p => Number(p.positionAmt) !== 0).map(p => ({
      symbol: p.symbol, side: Number(p.positionAmt) > 0 ? 'LONG' : 'SHORT',
      quantity: Math.abs(Number(p.positionAmt)), entryPrice: Number(p.entryPrice),
      markPrice: Number(p.markPrice), unrealizedPnl: Number(p.unRealizedProfit),
      liquidationPrice: Number(p.liquidationPrice), leverage: Number(p.leverage),
      marginType: p.marginType, isolatedMargin: Number(p.isolatedMargin || 0),
      notional: Number(p.notional || 0), positionAmt: Number(p.positionAmt)
    }));
    const safeOrders = (openOrders || []).map(o => ({ symbol:o.symbol, orderId:o.orderId, side:o.side, type:o.type, status:o.status, origQty:Number(o.origQty), executedQty:Number(o.executedQty), price:Number(o.price), stopPrice:Number(o.stopPrice), reduceOnly:o.reduceOnly, closePosition:o.closePosition, time:o.time }));
    const safeTrades = (userTrades || []).slice().reverse().map(t => ({ symbol:t.symbol, id:t.id, orderId:t.orderId, side:t.side, price:Number(t.price), quantity:Number(t.qty), quoteQty:Number(t.quoteQty), realizedPnl:Number(t.realizedPnl), commission:Number(t.commission), commissionAsset:t.commissionAsset, time:t.time, buyer:t.buyer, maker:t.maker }));
    const safeIncome = (income || []).slice().reverse().map(i => ({ symbol:i.symbol || '', incomeType:i.incomeType, income:Number(i.income), asset:i.asset, info:i.info || '', time:i.time, tradeId:i.tradeId }));
    return {
      mode:this.mode, updatedAt:Date.now(),
      summary:{ totalWalletBalance:Number(account.totalWalletBalance || 0), totalUnrealizedProfit:Number(account.totalUnrealizedProfit || 0), totalMarginBalance:Number(account.totalMarginBalance || 0), availableBalance:Number(account.availableBalance || 0), totalInitialMargin:Number(account.totalInitialMargin || 0), totalMaintMargin:Number(account.totalMaintMargin || 0), canTrade:Boolean(account.canTrade), canDeposit:Boolean(account.canDeposit), canWithdraw:Boolean(account.canWithdraw), assets },
      positions:openPositions, openOrders:safeOrders, trades:safeTrades, income:safeIncome
    };
  }
  async cancelAndVerifyCredentials() { this.credentials(); return this.signed('GET', '/fapi/v2/account'); }
}
